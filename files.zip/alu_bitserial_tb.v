// =================================================================
// Testbench : alu_bitserial
// -----------------------------------------------------------------
// Drives the bit-serial ALU with operands of SEVERAL DIFFERENT
// lengths in the same simulation run (4, 8, 16, 32 bits) to prove
// the "any size, same hardware" behaviour. Each operation is
// self-checked against a plain Verilog reference calculation.
// Run with: iverilog -o sim alu_bitserial.v alu_bitserial_tb.v && vvp sim
// =================================================================
`timescale 1ns/1ps

module alu_bitserial_tb;

    reg        clk, rst_n, start, a_in, b_in;
    reg  [2:0] opcode;
    reg  [7:0] length;
    wire       result_out, busy, done;
    wire       carry_borrow, zero, equal, greater, less;

    integer errors = 0;
    integer tests  = 0;

    alu_bitserial dut (
        .clk(clk), .rst_n(rst_n),
        .start(start), .opcode(opcode), .length(length),
        .a_in(a_in), .b_in(b_in),
        .result_out(result_out), .busy(busy), .done(done),
        .carry_borrow(carry_borrow), .zero(zero),
        .equal(equal), .greater(greater), .less(less)
    );

    // 50 MHz-style test clock (period irrelevant for functional sim)
    initial clk = 0;
    always #5 clk = ~clk;

    // -------------------------------------------------------------
    // Runs ONE operation of a given bit length and checks everything
    // -------------------------------------------------------------
    task run_op;
        input [63:0] aval;
        input [63:0] bval;
        input [7:0]  len;
        input [2:0]  op;
        input [255:0] name; // test label, printed as a string
        reg   [63:0] captured;
        reg   [64:0] mask;
        reg   [64:0] a_ext, b_ext, add_ext, sub_ext;
        reg          exp_carry, exp_zero, exp_eq, exp_gt, exp_lt;
        reg   [63:0] exp_result;
        integer i;
        begin
            tests = tests + 1;
            captured = 64'd0;

            // ---- drive the start pulse + first input bit ----
            @(posedge clk); #1;
            start  = 1'b1;
            opcode = op;
            length = len;
            a_in   = aval[0];
            b_in   = bval[0];
            @(posedge clk); #1;      // this edge just loads config (bit0 not yet processed)
            start  = 1'b0;

            // ---- stream all `len` bits, one per cycle ----
            // a_in/b_in already hold bit 0 (set before the start edge);
            // each edge below processes the bit currently on the wires,
            // so later bits are only changed AFTER their edge is clocked.
            for (i = 0; i < len; i = i + 1) begin
                if (i > 0) begin
                    a_in = aval[i];
                    b_in = bval[i];
                end
                @(posedge clk); #1;
                captured[i] = result_out;     // result for bit i is now valid
            end

            // ---- wait for the done pulse ----
            @(posedge clk); #1;
            if (!done) begin
                $display("[FAIL] %0s : expected done pulse, got none", name);
                errors = errors + 1;
            end

            // ---- reference (golden) calculation ----
            mask    = (65'd1 << len) - 65'd1;
            a_ext   = aval & mask;
            b_ext   = bval & mask;
            add_ext = a_ext + b_ext;
            sub_ext = a_ext - b_ext;

            case (op)
                3'b000: begin exp_result = add_ext[63:0] & mask; exp_carry = add_ext[len]; end
                3'b001: begin exp_result = sub_ext[63:0] & mask; exp_carry = sub_ext[len]; end
                3'b010: begin exp_result = a_ext & b_ext;        exp_carry = 1'b0; end
                3'b011: begin exp_result = a_ext | b_ext;        exp_carry = 1'b0; end
                default:begin exp_result = 64'd0;                exp_carry = 1'b0; end
            endcase
            exp_zero = (exp_result == 64'd0) && (op != 3'b100);
            exp_eq   = (a_ext == b_ext);
            exp_gt   = (a_ext >  b_ext);
            exp_lt   = (a_ext <  b_ext);

            // ---- checks ----
            if (op != 3'b100 && captured !== exp_result) begin
                $display("[FAIL] %0s : result = %0h, expected %0h", name, captured, exp_result);
                errors = errors + 1;
            end
            if ((op == 3'b000 || op == 3'b001) && carry_borrow !== exp_carry) begin
                $display("[FAIL] %0s : carry_borrow = %0b, expected %0b", name, carry_borrow, exp_carry);
                errors = errors + 1;
            end
            if (op != 3'b100 && zero !== exp_zero) begin
                $display("[FAIL] %0s : zero = %0b, expected %0b", name, zero, exp_zero);
                errors = errors + 1;
            end
            if (equal !== exp_eq || greater !== exp_gt || less !== exp_lt) begin
                $display("[FAIL] %0s : equal/greater/less = %0b/%0b/%0b, expected %0b/%0b/%0b",
                          name, equal, greater, less, exp_eq, exp_gt, exp_lt);
                errors = errors + 1;
            end

            if (errors == 0 || tests == 1)
                $display("[ run] %0s  (len=%0d)  a=%0d b=%0d  result=%0d  C/B=%0b Z=%0b EQ=%0b GT=%0b LT=%0b",
                          name, len, a_ext, b_ext, captured, carry_borrow, zero, equal, greater, less);

            @(posedge clk); #1; // one idle cycle between back-to-back ops
        end
    endtask

    initial begin
        $dumpfile("alu_bitserial.vcd");
        $dumpvars(0, alu_bitserial_tb);

        rst_n = 0; start = 0; a_in = 0; b_in = 0; opcode = 0; length = 0;
        repeat (3) @(posedge clk);
        rst_n = 1;
        @(posedge clk);

        // -------- 4-bit operands --------
        run_op(4'd5,  4'd3,  8'd4, 3'b000, "ADD_4bit");
        run_op(4'd3,  4'd5,  8'd4, 3'b001, "SUB_4bit_borrow");
        run_op(4'd12, 4'd10, 8'd4, 3'b010, "AND_4bit");
        run_op(4'd12, 4'd10, 8'd4, 3'b011, "OR_4bit");
        run_op(4'd7,  4'd7,  8'd4, 3'b100, "CMP_4bit_equal");

        // -------- 8-bit operands (matches the original parallel ALU) --------
        run_op(8'd200, 8'd55,  8'd8, 3'b000, "ADD_8bit_carry");
        run_op(8'd55,  8'd200, 8'd8, 3'b001, "SUB_8bit_borrow");
        run_op(8'd170, 8'd85,  8'd8, 3'b011, "OR_8bit");
        run_op(8'd90,  8'd12,  8'd8, 3'b100, "CMP_8bit_greater");

        // -------- 16-bit operands --------
        run_op(16'd50000, 16'd20000, 8'd16, 3'b000, "ADD_16bit");
        run_op(16'd1000,  16'd60000, 8'd16, 3'b001, "SUB_16bit_borrow");
        run_op(16'd4096,  16'd61439, 8'd16, 3'b100, "CMP_16bit_less");

        // -------- 32-bit operands : same hardware, no redesign --------
        run_op(32'd3000000000, 32'd500000000, 8'd32, 3'b000, "ADD_32bit");
        run_op(32'd500000000,  32'd3000000000,8'd32, 3'b001, "SUB_32bit_borrow");
        run_op(32'hFFFFFFFF,   32'hFFFFFFFF,  8'd32, 3'b010, "AND_32bit_allones");

        $display("----------------------------------------------------");
        if (errors == 0)
            $display(">>> ALL %0d TESTS PASSED (lengths: 4, 8, 16, 32 bits)", tests);
        else
            $display(">>> %0d of %0d TESTS FAILED", errors, tests);
        $display("----------------------------------------------------");

        $finish;
    end

endmodule
