# Bit-Serial ALU (Runtime-Variable Operand Length)

Digital Electronics project &mdash; **Logic Circuit Design (PBECT304)**,
S3 ECE 2, Government Engineering College Wayanad.

**Target board: Xilinx Spartan-6 FPGA** (e.g. XC6SLX9 &mdash; Spartan-6
LX9 MicroBoard, Nexys 3, Atlys, or similar Spartan-6 dev board).

## What this is

A follow-up to the original parameterized (fixed-WIDTH) ALU. That
design picks one bit-width at synthesis time (4-bit, 8-bit, 16-bit...)
and cannot change it afterwards. **This design accepts operands of
any length at runtime** &mdash; a 4-bit add, a 37-bit add, and a
200-bit add can all run on the exact same programmed hardware, one
after another, with no re-synthesis in between.

**How:** numbers are streamed into the ALU **one bit at a time**
(LSB first) over as many clock cycles as the chosen length, through a
single 1-bit-wide datapath, instead of arriving all at once on a
parallel bus. The trade-off is speed &mdash; an N-bit operation takes
roughly N+2 clock cycles, not 1.

## Files

```
alu_bitserial.v            - the bit-serial ALU module
alu_bitserial_tb.v         - self-checking testbench (tests 4/8/16/32-bit ops)
spartan6_constraints.ucf   - TEMPLATE pin constraints for Spartan-6 (ISE flow)
block_diagram.png          - Fig. 1: system-level black-box view
circuit_diagram.png        - Fig. 2: internal datapath view
```

## Interface

| Port | Direction | Width | Description |
|---|---|---|---|
| `clk` | input | 1 | System clock |
| `rst_n` | input | 1 | Active-low reset |
| `start` | input | 1 | Pulse 1 cycle to begin a new operation |
| `opcode` | input | 3 | Operation select (see table below) |
| `length` | input | 8 | **Operand length in bits (1&ndash;255) &mdash; set live, this is the "any size" control** |
| `a_in` | input | 1 | Operand A, one bit per cycle, LSB first |
| `b_in` | input | 1 | Operand B, one bit per cycle, LSB first |
| `result_out` | output | 1 | Result, one bit per cycle, LSB first |
| `busy` | output | 1 | High while an operation is running |
| `done` | output | 1 | 1-cycle pulse when the operation finishes |
| `carry_borrow` | output | 1 | Final carry-out (ADD) / borrow (SUB), valid at `done` |
| `zero` | output | 1 | 1 if result is all-zero, valid at `done` |
| `equal` | output | 1 | 1 if a == b, valid at `done` |
| `greater` | output | 1 | 1 if a > b, valid at `done` |
| `less` | output | 1 | 1 if a < b, valid at `done` |

## Supported operations

| opcode | Operation |
|---|---|
| `000` | ADD |
| `001` | SUB |
| `010` | AND |
| `011` | OR |
| `100` | CMP (equal / greater / less, flags only) |

## How it works

- **Four units compute every cycle**, each handling one bit of `a_in`/`b_in`:
  a full adder/subtractor (with a carry/borrow flip-flop that feeds
  back into itself the next cycle &mdash; this is the serial carry
  chain), an AND gate, an OR gate, and a comparator.
- A **4:1 mux**, steered by `opcode`, passes the active unit's bit to
  `result_out` each cycle.
- A **bit counter compares against `length`** every cycle; when it
  reaches `length`, the operation is done &mdash; `length` is read
  fresh on every `start` pulse, so it can be a different value every
  single operation.
- The **comparator** updates `equal`/`greater`/`less` only when
  `a_in != b_in`. Because bits are processed low-to-high, a mismatch
  on a later (higher) bit simply overwrites an earlier tentative
  result &mdash; by construction, whatever is left after the last bit
  is the correct magnitude comparison.
- `zero` is an OR-accumulator over every result bit seen, inverted at
  the end.

See `block_diagram.png` (black-box view) and `circuit_diagram.png`
(internal datapath view) for the visual versions of the above.

## Requirements

- [Icarus Verilog](http://iverilog.icarus.com/) (`iverilog`, `vvp`) for simulation
- [GTKWave](http://gtkwave.sourceforge.net/) (optional, waveform viewing)
- **Xilinx ISE WebPACK 14.7** for Spartan-6 synthesis &mdash; Spartan-6
  is **not** supported by Vivado; ISE is the last toolchain that
  targets this device family.

On Ubuntu/Debian: `sudo apt install iverilog gtkwave`

## Running the simulation

```bash
iverilog -o sim alu_bitserial.v alu_bitserial_tb.v
vvp sim
```

Expected output:

```
>>> ALL 15 TESTS PASSED (lengths: 4, 8, 16, 32 bits)
```

Inspect signal timing:

```bash
gtkwave alu_bitserial.vcd
```

## Synthesizing for Spartan-6 (ISE)

1. Open **ISE WebPACK**, create a new project, set the family/device
   to **Spartan-6**, part **XC6SLX9** (or your board's exact part
   number &mdash; check your board's reference manual).
2. Add `alu_bitserial.v` as the only design source (the testbench is
   simulation-only, do not add it to synthesis).
3. Add `spartan6_constraints.ucf` and **edit every `LOC` pin** to
   match your actual board &mdash; the included file is a template;
   pin names differ between Spartan-6 boards even on the same chip.
4. Run **Synthesize &rarr; Implement &rarr; Generate Programming File**.
5. Program the board with the resulting `.bit` file via JTAG
   (iMPACT, or your board's loader tool).

## Using it on the board

- Flip `length` DIP switches to the bit-width you want for this
  operation (e.g. `00001000` = 8, `00010000` = 16).
- Set `opcode` switches to the desired operation.
- Press `start` once.
- Toggle `a_in`/`b_in` switches to the correct value **for each bit**,
  pulsing the clock (or stepping a manual/debounced clock) once per
  bit, LSB first &mdash; watch `result_out` LED after each step, and
  the flag LEDs once `done` lights up.
- For a convincing demo, wire `a_in`/`b_in` from small **shift
  registers** (loaded in parallel from switches, then shifted out
  automatically on each clock) rather than toggling switches by hand
  for every single bit &mdash; this is a natural Module 2 extension
  (shift registers) to pair with this mini-project.

## Verification

All 15 directed tests pass in simulation across **4, 8, 16, and
32-bit** operand lengths run back-to-back on the same instantiated
hardware (ADD, SUB with borrow, AND, OR, CMP for equal/greater/less),
self-checked against a reference Verilog calculation in the
testbench.

## License

Academic project &mdash; Government Engineering College Wayanad.
