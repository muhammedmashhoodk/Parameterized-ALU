// =================================================================
// Bit-Serial ALU  --  runtime-variable operand length
// -----------------------------------------------------------------
// Project  : Calculator SoC (Logic Circuit Design, PBECT304, S3 ECE 2)
// Target   : Xilinx Spartan-6 FPGA (e.g. XC6SLX9), ISE / XST synthesis
// Module   : alu_bitserial
// -----------------------------------------------------------------
// Unlike a parallel ALU (fixed WIDTH, chosen at synthesis time), this
// ALU accepts operands of ANY length at RUNTIME. Numbers are streamed
// in one bit at a time (LSB first) over as many clock cycles as the
// chosen length, through a single 1-bit-wide datapath. The length is
// carried on the `length` input port and can change between
// operations -- a 4-bit add, then a 37-bit add, then a 200-bit add
// can all be run back-to-back on the exact same hardware.
//
// Trade-off: this takes `length` clock cycles to finish (plus 1 cycle
// of setup and 1 cycle to publish flags), instead of finishing in a
// single cycle like a parallel ALU. That is the real-world cost of
// true arbitrary-length arithmetic.
// =================================================================

module alu_bitserial (
    input  wire       clk,
    input  wire       rst_n,         // active-low synchronous-style reset

    input  wire       start,         // pulse HIGH for 1 cycle to begin a new op
    input  wire [2:0] opcode,        // 000 ADD, 001 SUB, 010 AND, 011 OR, 100 CMP
    input  wire [7:0] length,        // operand length in bits (1-255), sampled on start

    input  wire       a_in,          // operand A, one bit per cycle, LSB first
    input  wire       b_in,          // operand B, one bit per cycle, LSB first

    output reg        result_out,    // result, one bit per cycle, LSB first (valid while busy)
    output reg        busy,          // 1 while an operation is in progress
    output reg        done,          // 1-cycle pulse when the operation finishes

    output reg        carry_borrow,  // final carry-out (ADD) / borrow (SUB) - valid at done
    output reg        zero,          // 1 if result is all-zero               - valid at done
    output reg        equal,         // 1 if a == b                            - valid at done
    output reg        greater,       // 1 if a >  b                            - valid at done
    output reg        less           // 1 if a <  b                            - valid at done
);

    // -----------------------------------------------------------
    // Opcode encoding - identical meaning to the parallel ALU
    // -----------------------------------------------------------
    localparam OP_ADD = 3'b000;
    localparam OP_SUB = 3'b001;
    localparam OP_AND = 3'b010;
    localparam OP_OR  = 3'b011;
    localparam OP_CMP = 3'b100;

    // -----------------------------------------------------------
    // Internal state
    // -----------------------------------------------------------
    reg [7:0] bit_cnt;     // which bit index we are currently processing
    reg [7:0] op_length;   // length latched at start (the "any size" value)
    reg [2:0] op_reg;      // opcode latched at start
    reg       carry_ff;    // 1-bit carry (ADD) / borrow (SUB) chain
    reg       any_one_ff;  // OR-accumulator -> drives the zero flag
    reg       eq_ff;       // running equality result
    reg       gt_ff;       // running "a greater" result
    reg       lt_ff;       // running "a less" result

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy         <= 1'b0;
            done         <= 1'b0;
            bit_cnt      <= 8'd0;
            op_length    <= 8'd0;
            op_reg       <= 3'd0;
            carry_ff     <= 1'b0;
            any_one_ff   <= 1'b0;
            eq_ff        <= 1'b1;
            gt_ff        <= 1'b0;
            lt_ff        <= 1'b0;
            result_out   <= 1'b0;
            carry_borrow <= 1'b0;
            zero         <= 1'b0;
            equal        <= 1'b0;
            greater      <= 1'b0;
            less         <= 1'b0;
        end else begin
            done <= 1'b0;  // default: only pulses for exactly one cycle

            if (start && !busy) begin
                // ---- Load a new operation. `length` can be anything
                // ---- from 1 to 255 here - this is the runtime knob
                // ---- that replaces the fixed WIDTH parameter.
                busy       <= 1'b1;
                bit_cnt    <= 8'd0;
                op_length  <= length;
                op_reg     <= opcode;
                carry_ff   <= 1'b0;
                any_one_ff <= 1'b0;
                eq_ff      <= 1'b1;
                gt_ff      <= 1'b0;
                lt_ff      <= 1'b0;

            end else if (busy) begin
                if (bit_cnt == op_length) begin
                    // All `op_length` bits were processed on previous
                    // cycles - publish the final flags and stop.
                    busy         <= 1'b0;
                    done         <= 1'b1;
                    carry_borrow <= carry_ff;
                    zero         <= ~any_one_ff;
                    equal        <= eq_ff;
                    greater      <= gt_ff;
                    less         <= lt_ff;

                end else begin
                    // ---- Process bit #bit_cnt this cycle ----
                    case (op_reg)
                        OP_ADD: begin
                            result_out <= a_in ^ b_in ^ carry_ff;
                            carry_ff   <= (a_in & b_in) | (a_in & carry_ff) | (b_in & carry_ff);
                            any_one_ff <= any_one_ff | (a_in ^ b_in ^ carry_ff);
                        end

                        OP_SUB: begin
                            // full subtractor: diff = a XOR b XOR borrow_in
                            result_out <= a_in ^ b_in ^ carry_ff;
                            carry_ff   <= (~a_in & b_in) | (~a_in & carry_ff) | (b_in & carry_ff);
                            any_one_ff <= any_one_ff | (a_in ^ b_in ^ carry_ff);
                        end

                        OP_AND: begin
                            result_out <= a_in & b_in;
                            any_one_ff <= any_one_ff | (a_in & b_in);
                        end

                        OP_OR: begin
                            result_out <= a_in | b_in;
                            any_one_ff <= any_one_ff | (a_in | b_in);
                        end

                        OP_CMP: begin
                            result_out <= 1'b0;  // CMP has no numeric result, flags only
                        end

                        default: result_out <= 1'b0;
                    endcase

                    // ---- Serial magnitude comparator ----
                    // Bits arrive LSB-first, but whichever bit differs
                    // AT THE HIGHEST position decides the comparison.
                    // Simply overwriting gt/lt/eq on every mismatch
                    // guarantees the LAST mismatch seen (= the highest
                    // bit, since we go low-to-high) wins automatically.
                    if (a_in != b_in) begin
                        gt_ff <= a_in;   // a_in=1,b_in=0 -> a greater
                        lt_ff <= b_in;   // a_in=0,b_in=1 -> a less
                        eq_ff <= 1'b0;
                    end

                    bit_cnt <= bit_cnt + 8'd1;
                end
            end
        end
    end

endmodule
